package global

var CloudProviderMap = map[string]string{
	"aws":     "AWS (Amazon Web Services)",
	"alibaba": "阿里云 (Alibaba Cloud)",
	"tencent": "腾讯云 (Tencent Cloud)",
	"huawei":  "华为云 (Huawei Cloud)",
}
