package global

const (
	AppDirName = ".config/cf"
	Version    = "v0.5.0"
	UpdateTime = "2023.7.1"
)
